NISE

La carpeta se divide de la siguiente manera:
1. SPMP.pdf: Documentaci�n primera entrega.
2. Anexos: - Bizagi Models: Modelos de los procesos realizados en Bizagi.
	   - Use Case Points: Plantilla utilizada para la estimaci�n.
	   - Planeaci�nJbook.mpp: Diagrama de gantt con la planeaci�n del proyecto.
	   - Presentacion de la primera entrega.